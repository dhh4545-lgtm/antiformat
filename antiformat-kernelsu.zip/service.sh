#!/system/bin/sh
# AntiFormat service - 开机自动加载 antiformat 内核模块并应用保护
# 适配 v0.2.0: 永久驻留 + 64进制key卸载认证 + 逻辑卸载
# 注意: 必须等系统完全启动后再加载, 否则 persist/基带初始化写会被拦截导致分区坏死
MODDIR=${0%/*}

KOMOD="/data/adb/modules/antiformat/lib/modules/antiformat.ko"
PROT_LIST="$MODDIR/protect.list"
LOGF="/data/adb/modules/antiformat/antiformat.log"

log() {
  echo "[antiformat] $*" >> "$LOGF" 2>&1
  echo "[antiformat] $*" > /dev/kmsg 2>/dev/null || true
}

# 0) 等待系统完全启动 (persist/基带/传感器初始化完成后再加载, 防分区坏死)
#    最长等 120 秒, 每 2 秒检查一次
n=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  n=$((n + 1))
  if [ $n -ge 60 ]; then
    log "WARN: sys.boot_completed not set after 120s, continuing anyway"
    break
  fi
  sleep 2
done
log "boot_completed=$(getprop sys.boot_completed 2>/dev/null) (waited $((n * 2))s)"

# 1) 加载内核模块（重复加载返回 EEXIST，属正常——说明已加载）
if [ -f "$KOMOD" ]; then
  /system/bin/insmod "$KOMOD" 2>/dev/null
  rc=$?
  if [ $rc -eq 0 ]; then
    log "insmod OK"
  else
    log "insmod rc=$rc (EEXIST=已加载, 正常)"
  fi
else
  log "module not found: $KOMOD"
fi

# 2) 应用自定义保护目录（/proc/antiformat/protect 接口, 每行一个路径）
if [ -d /proc/antiformat ]; then
  # 打印卸载 key 到日志（方便用户日后逻辑卸载）
  KEY=$(dmesg 2>/dev/null | grep -o 'unload key: [0-9A-Za-z_-]*' | tail -1 | awk '{print $NF}')
  if [ -n "$KEY" ]; then
    log "unload key: $KEY"
  else
    log "unload key not found in dmesg (dmesg_restrict?)"
  fi

  if [ -f "$PROT_LIST" ]; then
    while IFS= read -r line; do
      case "$line" in
        ""|\#*) continue ;;
      esac
      echo "$line" > /proc/antiformat/protect 2>/dev/null
      log "protect +$line"
    done < "$PROT_LIST"
  fi
  log "status: $(cat /proc/antiformat/status 2>/dev/null | tr '\n' ' ')"
else
  log "/proc/antiformat not available (module not loaded?)"
fi

# 3) 让日志可读
chmod 666 "$LOGF" 2>/dev/null

exit 0