#!/system/bin/sh
# AntiFormat uninstall - 卸载前做逻辑卸载（防护停用）
# 注意: v0.2.0 模块永久驻留(refcount 钉死), rmmod 会被 EBUSY 拒绝,
#       正确停用方式 = 用 64进制 key 写 /proc/antiformat/unload 逻辑卸载。
#       逻辑卸载后模块仍驻留内核, 但 disabled=1 防护已停, 无副作用。
MODDIR=${0%/*}
LOGF="/data/adb/modules/antiformat/antiformat.log"

# 从 dmesg 提取卸载 key（加载时打印过）
KEY=$(dmesg 2>/dev/null | grep -o 'unload key: [0-9A-Za-z_-]*' | tail -1 | awk '{print $NF}')

if [ -d /proc/antiformat ]; then
  if [ -n "$KEY" ]; then
    echo "$KEY" > /proc/antiformat/unload 2>/dev/null
    echo "[antiformat] logical unload via key OK" >> "$LOGF" 2>/dev/null
  else
    echo "[antiformat] WARN: key not found, 无法逻辑卸载, 防护仍激活" >> "$LOGF" 2>/dev/null
  fi
fi

# 清理日志
rm -f "$LOGF" 2>/dev/null

exit 0