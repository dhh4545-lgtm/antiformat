#!/system/bin/sh
# AntiFormat customize.sh - KernelSU 安装脚本 (安装 zip 时由管理器执行)
# 功能: 架构检查 + 提示, 无系统文件替换, 纯内核模块

ui_print "*******************************"
ui_print " AntiFormat 防格机保护模块 v0.2.0"
ui_print "*******************************"

# 1) 架构检查 (KernelSU 提供 $ARCH; 兜底用 uname -m)
ARCH_CHK="${ARCH:-$(uname -m 2>/dev/null)}"
case "$ARCH_CHK" in
  arm64|aarch64|arm64-v8a)
    ui_print "- 架构 OK: $ARCH_CHK"
    ;;
  *)
    abort "错误: 仅支持 arm64 (aarch64) 设备, 当前: $ARCH_CHK"
    ;;
esac

# 2) 内核版本展示 (仅供确认兼容性)
ui_print "- 当前内核: $(uname -r 2>/dev/null)"

# 3) 检查 /proc/antiformat 是否已存在 (旧模块残留会提示)
if [ -d /proc/antiformat ]; then
  ui_print "- 警告: 检测到 antiformat 已在内核中 (旧版残留)"
  ui_print "  将使用最新版覆盖, 重启后生效"
fi

# 4) 提示卸载 key 查看方式
ui_print "- 安装完成!"
ui_print "- 重启后卸载 key 查看:"
ui_print "  cat /data/adb/modules/antiformat/antiformat.log"
ui_print "  (或 dmesg | grep 'unload key')"

exit 0